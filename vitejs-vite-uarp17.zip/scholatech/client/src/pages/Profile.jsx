import AuthUserLayout from '../components/AuthUserLayout';

const Profile = () => {
  return (
    <AuthUserLayout>
      <h1>Página de perfil</h1>
    </AuthUserLayout>
  );
};

export default Profile;
